<template>
    <router-view></router-view>
    <!-- <h1>sdfsdfsdfds</h1> -->
</template>

<script setup>
import { useRouter } from 'vue-router'
// import { useUserStore } from "@/stores/user.js"

let router = useRouter()
// let userStore = useUserStore()

</script>