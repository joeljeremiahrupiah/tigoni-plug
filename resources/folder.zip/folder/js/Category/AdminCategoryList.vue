<template>
    <div class="az-content-body pd-lg-l-40 d-flex flex-column">
        <!-- <div class="az-content-breadcrumb mb-5">
            <span>Components</span>
            <span>UI Elements</span>
            <span>Buttons</span>
        </div> -->


        <div class="page-body">
            <div class="container-xl">

                <div class="row">
                    <div class="col-md-4" v-for="(fixture, index) in fixturemaindata" :key="index">
                        <el-card class="box-card" v-for="fixturedata in  fixture.fixturedatas" :key="fixturedata.id">
                            <template #header>
                                <el-collapse v-model="activeName" accordion>
                                    <el-collapse-item v-for="fixturedata in  fixture.fixturedatas" :key="fixturedata.id"
                                        :title="fixturedata.league" :name="index.toString()">
                                        <div class="card-header d-flex justify-content-between">
                                            <div class="az-content-label mg-b-5 d-flex justify-content-between">
                                                <img :src="fixturedata?.country_logo" alt=""
                                                    style="width: auto;max-width: 50px;height: auto;max-height: 50px;">
                                                <div style="display:block">
                                                    <p>{{ fixturedata?.league }}</p>
                                                    <p>{{ fixturedata?.country }}</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            Content specific to each collapse item
                                            Add your desired content here
                                        </div>
                                    </el-collapse-item>
                                </el-collapse>

                            </template>
                            <span></span>
                            <template #footer>Footer content</template>


                        </el-card>
                    </div>
                </div>
            </div>
        </div>

        <el-dialog v-model="dialogVisible" :title="titleChange" width="30%" :before-close="handleClose">
            <span>
                <form>
                    <label class="mb-2"> Category Name </label>
                    <el-input v-model="form.title" />
                </form>

            </span>
            <template #footer>
                <span class="dialog-footer">
                    <el-button @click="closeCategoryModal">Cancel</el-button>
                    <el-button v-show="!editmode" type="primary" @click="createCategory" :loading="loading">
                        {{ loading ? 'Processing ... ' : 'Create' }}
                    </el-button>
                    <el-button v-show="editmode" type="primary" @click="updateCategory" :loading="loading">
                        {{ loading ? 'Processing ... ' : 'Update' }}
                    </el-button>
                </span>
            </template>
        </el-dialog>

    </div>
</template>
  
<script setup>
import { onMounted, ref } from "vue";
import axios from "axios";
import { ElMessageBox, ElNotification } from "element-plus";
import moment from "moment"

let categories = ref([]);

let dialogVisible = ref(false)

let editmode = ref(false)

let loading = ref(false)

let titleChange = ref('')

let fixturemaindata = ref([])

let form = ref({
    id: '',
    title: ''
})

const createCategoryModal = () => {
    editmode.value = false
    form.value = {}
    titleChange.value = 'Create Category'
    dialogVisible.value = true
}

const closeCategoryModal = () => {
    editmode.value = false
    form.value = {}
    loading.value = false
    dialogVisible.value = false
}

const openEditCategoryModal = (category) => {
    editmode.value = true
    titleChange.value = 'Edit Category'
    form.value.title = category.title
    form.value.id = category.id
    dialogVisible.value = true
}

const createCategory = async () => {
    loading.value = true
    const response = await axios.post('/admin/create-categories', form.value);
    if (response.status == 200) {
        ElNotification({
            title: 'Success',
            message: 'Category created successfully',
            type: 'success',
        });
        loading.value = false
        dialogVisible.value = false
        getAllCategories()
    } else {
        ElNotification({
            title: 'Error',
            message: 'An error occured. Please try again',
            type: 'error',
        });
        loading.value = false
        dialogVisible.value = false
        getAllCategories()
    }
    loading.value = false
    getAllCategories()
};

const updateCategory = async () => {
    loading.value = true
    const response = await axios.post(`/admin/update-categories/${form.value.id}`, form.value);
    if (response.status == 200) {
        ElNotification({
            title: 'Success',
            message: 'Category updated successfully',
            type: 'success',
        });
        loading.value = false
        dialogVisible.value = false
        getAllCategories()
    } else {
        ElNotification({
            title: 'Error',
            message: 'An error occured. Please try again',
            type: 'error',
        });
        loading.value = false
        dialogVisible.value = false
        getAllCategories()
    }
    loading.value = false
    getAllCategories()
};

const deleteCategory = async (categoryId) => {
    try {
        const response = await ElMessageBox.confirm('Are you sure you want to delete this category?', 'Warning', {
            confirmButtonText: 'Delete',
            cancelButtonText: 'Cancel',
            type: 'warning',
        });

        if (response === 'confirm') {
            await axios.delete(`/admin/destroy-categories/${categoryId}`);
            categories.value = categories.value.filter((category) => category.id !== categoryId);
            ElNotification({
                title: 'Success',
                message: 'Category deleted successfully',
                type: 'success',
            });
            getAllCategories()
        }
    } catch (error) {
        console.error(error);
        getAllCategories()
    }
};

const getAllCategories = async () => {
    try {
        const response = await axios.get('/admin/get-categories');
        categories.value = response.data.categories;
    } catch (error) {
        console.error(error);
    }
};

const getAllFixtures = async () => {
    try {
        const token = localStorage.getItem('token');
        console.log(token);

        const response = await axios.get('/todays-fixtures', {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });

        console.log(response.data);
        fixturemaindata.value = response.data.fixturemaindata;
    } catch (error) {
        console.error(error);
    }
};


onMounted(() => {
    getAllCategories();
    getAllFixtures()
});
</script>
  