<template>
    <div class="page-wrapper">
        <user-header></user-header>

        <div class="container mt-4">
            <h1 class="mb-4">Account</h1>

            <div class="row">
                <div class="col-md-12 mb-4">
                    <!-- Sidebar with tabs -->
                    <el-tabs v-model="activeTab" tab-position="left" class="account-tabs">
                        <el-tab-pane label="Orders">
                            <el-card class="box-card">
                                <template #header>
                                    <div class="card-header">
                                        <span>Edit Orders</span>
                                        <!-- <el-button class="button" text>Operation button</el-button> -->
                                    </div>
                                </template>
                            </el-card>
                        </el-tab-pane>
                        <el-tab-pane label="Details">
                            <el-card class="box-card">
                                <template #header>
                                    <div class="card-header">
                                        <span>Edit Details</span>
                                        <!-- <el-button class="button" text>Operation button</el-button> -->
                                    </div>
                                </template>
                            </el-card>
                        </el-tab-pane>
                        <el-tab-pane label="Settings">
                            <el-card class="box-card">
                                <template #header>
                                    <div class="card-header">
                                        <span>Edit Settings</span>
                                        <!-- <el-button class="button" text>Operation button</el-button> -->
                                    </div>
                                </template>
                            </el-card>
                        </el-tab-pane>
                    </el-tabs>
                </div>

                <!-- <div class="col-lg-9">
                    <div v-if="activeTab === 'Orders'" class="tab-content">
                        <p>This is the Orders tab content.</p>
                    </div>

                    <div v-if="activeTab === 'Details'" class="tab-content">
                        <p>This is the Details tab content.</p>
                    </div>

                    <div v-if="activeTab === 'Settings'" class="tab-content">
                        <p>This is the Settings tab content.</p>
                    </div>
                </div> -->
            </div>
        </div>

        <user-footer></user-footer>
    </div>
</template>

<script setup>
import { ref } from 'vue';
import UserHeader from '../inc/Header.vue';
import UserFooter from '../inc/Footer.vue';

const activeTab = ref('Orders'); // Set the default active tab
</script>

<style scoped>
/* Custom styles */
.account-tabs {
    background-color: #f8f9fa;
    /* Light gray background color for the tabs */
}

.tab-content {
    background-color: #ffffff;
    /* White background color for tab content */
    padding: 20px;
    border: 1px solid #ced4da;
    /* Border color for tab content */
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    /* Box shadow for a subtle lift */
}

@media (max-width: 767px) {
    .account-tabs {
        tab-position: top;
    }

    .col-lg-3 {
        width: 100%;
        margin-bottom: 20px;
    }
}
</style>
